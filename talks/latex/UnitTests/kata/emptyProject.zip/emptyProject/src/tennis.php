<?php
namespace TennisKata;

require __DIR__ . '/../vendor/autoload.php';

$implementation = new Implement();

$implementation->run($argv);
