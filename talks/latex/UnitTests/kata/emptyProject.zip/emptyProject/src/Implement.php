<?php
namespace TennisKata;

class Implement
{
    public function run($arguments)
    {
        var_export($arguments);
    }
}
