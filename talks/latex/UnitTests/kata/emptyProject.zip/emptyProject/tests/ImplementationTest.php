<?php
namespace TennisKata\Tests;

use PHPUnit\Framework\TestCase;

class ImplementationTest extends TestCase
{
    /**
    * @test
    */
    public function runTest()
    {
        self::assertTrue(true);
    }
}
